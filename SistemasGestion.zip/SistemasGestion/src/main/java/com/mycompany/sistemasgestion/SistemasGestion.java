/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemasgestion;

/**
 *
 * @author edwin
 */
public class SistemasGestion {

    public static void main(String[] args) {
        System.out.println("hello word");
         Formulario ventana = new Formulario();
        ventana.show();
    }
}
